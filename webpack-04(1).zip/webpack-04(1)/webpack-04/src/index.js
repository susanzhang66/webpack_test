// const webpack = require("webpack");
// const webpackConfig = require("../webpack.config.js");

// const compiler = webpack(webpackConfig);
// Object.keys(compiler.hooks).forEach((hookName) => {
//   compiler.hooks[hookName].tap("laohan", () => {
//     console.log(`run ------ > ${hookName}`);
//   });
// });

// compiler.run();

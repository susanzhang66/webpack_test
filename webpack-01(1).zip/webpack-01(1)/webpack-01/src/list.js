import { str } from "./a.js";

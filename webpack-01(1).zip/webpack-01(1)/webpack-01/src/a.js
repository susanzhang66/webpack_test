export const str = "老韩";

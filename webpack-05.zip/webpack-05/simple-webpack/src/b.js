export const str2 = "!!!!";

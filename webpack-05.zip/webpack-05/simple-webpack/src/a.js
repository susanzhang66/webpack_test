import { str2 } from "./b.js";
export const str = `webpack5 ${str2}`;

import { str } from "./a.js";

console.log(`hello ${str}`);

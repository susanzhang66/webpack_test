module.exports = function (source) {
  return JSON.stringify(source);
};

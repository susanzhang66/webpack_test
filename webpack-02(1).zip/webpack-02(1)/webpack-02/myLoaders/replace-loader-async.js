// 自定义loader
// loader 就是一个函数 ，不可以是箭头函数
// loader必须有返回值
// loader如何接受参数
// loader 的 api 都挂载this对象上
// 如何返回多种信息 this.callback
// 如何处理异步逻辑 this.async
// 多个自定义loader如何处理
module.exports = function (source) {
  console.log(this, this.query, source);
  const callback = this.async();
  setTimeout(() => {
    const content = source.replace("hello", "哈哈");
    callback(null, content);
  }, 3000);
  //   this.callback(null, content);
  //   return source.replace("hello", this.query.name);
};

// add
// bundle文件：压缩版，未压缩版
// 打包规范 umd

export default function add(a, b) {
  return a + b;
}

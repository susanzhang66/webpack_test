import css from "./css/index.less";
import { add } from "./expo.js";
console.log(add(1, 2));

// import React, { Component } from "react";
// import ReactDom from "react-dom";

// class App extends Component {
//   render() {
//     return <div>hello world</div>;
//   }
// }

// ReactDom.render(<App />, document.getElementById("app"));

export const add = (a, b) => {
  console.log("aaaaaaa");
  return a + b;
};

export const minus = (a, b) => {
  console.log("bbbbbb");
  return a - b;
};

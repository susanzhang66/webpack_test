// import addNum from "kkb-lib-test";
// defalut
const addNum = require("kkb-lib-test");
console.log(addNum.default(10, 10));
